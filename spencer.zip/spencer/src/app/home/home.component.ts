import { Component, OnInit, ViewChild } from '@angular/core';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @ViewChild(HeaderComponent,{static:false} ) header: HeaderComponent ; 
  constructor() { }
  showHeaderMsg='Change Header Without Search bar';
  ngOnInit() {
  }
  toggleHeader(){
    this.header.toggleHeader();
    if(this.showHeaderMsg =='Change Header Without Search bar'){
      this.showHeaderMsg='Change Header With Search bar';
    }else{
      this.showHeaderMsg='Change Header Without Search bar'
    }
  }
}
