import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
 
  searchHeader:boolean=false;
  mainHeader:boolean=true;
  constructor() { }

  ngOnInit() {
  }
  toggleHeader(){
    if(this.searchHeader==false){
       this.searchHeader=true;
       this.mainHeader=false;
    }else{
       this.searchHeader=false;
       this.mainHeader=true;
    }
    
  
  }
}
