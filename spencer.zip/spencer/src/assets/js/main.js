/*****client-slider*****/
$(document).ready(function() {
$('#slider_product').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    autoplay:true,
    navText:[],
   autoplaySpeed: 4000,
   autoplayTimeout:8000,
   //smartSpeed:2000,
    //center:true,
    responsiveClass:true,	
    responsive:{
        0:{
            items:1,
            nav:true,
            loop:true
        },
        600:{
            items:1,
            nav:true,
            loop:true
        },
        1000:{
            items:1,
            nav:true,
            loop:true
        }
    }
});


/*****client-slider*****/
$('#slider_baner').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    animateOut: 'fadeOut',
    autoplay:true,
    navText:[],
   autoplaySpeed: 4000,
   autoplayTimeout:8000,
   //smartSpeed:2000,
    //center:true,
    responsiveClass:true,	
    responsive:{
        0:{
            items:1,
            nav:true,
            loop:true
        },
        600:{
            items:1,
            nav:true,
            loop:true
        },
        1000:{
            items:1,
            nav:true,
            loop:true
        }
    }
});



/*****Fixed Header*********/
$(window).scroll(function () {

    var scroll = $(window).scrollTop();

    if (scroll > 50) {

        $(".tob-bar-fix").addClass('fixedmenu')

    } else {

        $(".tob-bar-fix").removeClass('fixedmenu');

    }

});
})




